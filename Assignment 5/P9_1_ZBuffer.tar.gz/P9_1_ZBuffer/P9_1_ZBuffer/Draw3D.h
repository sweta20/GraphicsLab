void setShapeData(char inp[]);
